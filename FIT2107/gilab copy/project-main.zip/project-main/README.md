﻿FIT2107 Assignment 2 Repository 
MA_Lab02_Team5

Team Members:
 - Jobin Mathew Dan
 - Sayyidina Shaquille Malcolm
 - Kennedy Sing Ye Tan